export interface HouseRequest {
    streetId: number;
    houseNumber: string;
}