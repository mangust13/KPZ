export interface HouseResponse {
    id: number;
    cityName: string;
    streetName: string;
    houseNumber: string;
}