import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHouseComponent } from './add-house.component';

describe('AddHouseComponent', () => {
  let component: AddHouseComponent;
  let fixture: ComponentFixture<AddHouseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddHouseComponent]
    });
    fixture = TestBed.createComponent(AddHouseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
