export interface ConnectionRequestRequest {
    clientId: number;
    internetTariffId: number;
    internetConnectionRequestStatusId: number;
    number: string;
}