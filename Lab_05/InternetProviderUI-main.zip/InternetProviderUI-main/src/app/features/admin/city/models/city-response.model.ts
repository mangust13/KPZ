export interface CityResponse {
    id: number;
    name: string;
}