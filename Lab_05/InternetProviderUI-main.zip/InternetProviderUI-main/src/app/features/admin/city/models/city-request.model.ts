export interface CityRequest {
    name: string
}