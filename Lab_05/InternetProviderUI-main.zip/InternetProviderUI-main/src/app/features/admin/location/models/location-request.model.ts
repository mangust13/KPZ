export interface LocationRequest {
    locationTypeId: number;
    houseId: number;
    apartmentNumber?: number;
}