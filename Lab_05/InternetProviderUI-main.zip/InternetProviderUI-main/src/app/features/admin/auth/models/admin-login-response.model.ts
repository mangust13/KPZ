export interface AdminLoginResponse {
    userName: string;
    token: string;
    role: string;
}