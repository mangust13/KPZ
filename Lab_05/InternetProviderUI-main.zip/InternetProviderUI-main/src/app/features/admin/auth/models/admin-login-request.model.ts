export interface AdminLoginRequest {
    userName: string;
    password: string;
}