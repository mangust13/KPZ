export interface AdminLogin {
    userName: string;
    role: string;
}