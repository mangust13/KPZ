export interface ClientStatusResponse {
    id: number;
    name: string;
}