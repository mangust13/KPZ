export interface ClientStatusRequest {
    name: string
}