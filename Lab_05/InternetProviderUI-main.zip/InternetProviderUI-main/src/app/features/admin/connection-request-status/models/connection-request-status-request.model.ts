export interface ConnectionRequestStatusRequest {
    name: string
}