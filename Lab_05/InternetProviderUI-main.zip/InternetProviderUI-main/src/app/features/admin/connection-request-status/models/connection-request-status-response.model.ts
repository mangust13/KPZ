export interface ConnectionRequestStatusResponse {
    id: number;
    name: string;
}