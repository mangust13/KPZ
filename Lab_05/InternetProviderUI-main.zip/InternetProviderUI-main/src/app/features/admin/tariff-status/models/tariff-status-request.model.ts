export interface TariffStatusRequest {
    name: string
}