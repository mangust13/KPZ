export interface TariffStatusResponse {
    id: number;
    name: string;
}