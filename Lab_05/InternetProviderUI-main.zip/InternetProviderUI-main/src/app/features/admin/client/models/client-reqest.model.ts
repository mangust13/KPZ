export interface ClientRequest {
    clientStatusId: number;
    locationId: number;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    email: string;
}