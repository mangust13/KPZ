export enum SortType {
    Ascending,
    Descending
}