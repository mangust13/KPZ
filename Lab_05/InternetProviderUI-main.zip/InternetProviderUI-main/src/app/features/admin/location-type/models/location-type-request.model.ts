export interface LocationTypeRequest {
    name: string
}