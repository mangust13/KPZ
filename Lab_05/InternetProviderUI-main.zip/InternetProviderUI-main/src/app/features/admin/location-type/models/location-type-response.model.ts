export interface LocationTypeResponse {
    id: number;
    name: string;
}