export interface StreetRequest {
    cityId: number;
    name: string;
}