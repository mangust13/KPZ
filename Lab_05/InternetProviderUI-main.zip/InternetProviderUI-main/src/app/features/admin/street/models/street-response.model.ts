export interface StreetResponse {
    id: number;
    cityName: string;
    streetName: string;
}