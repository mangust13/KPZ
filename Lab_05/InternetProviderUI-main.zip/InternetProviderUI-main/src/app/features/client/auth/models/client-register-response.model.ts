export interface ClientRegisterResponse {
    userName: string;
    role: string;
    clientId: number;
}