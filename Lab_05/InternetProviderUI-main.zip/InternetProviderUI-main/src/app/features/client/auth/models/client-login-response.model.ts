export interface ClientLoginResponse {
    userName: string;
    token: string;
    role: string;
    clientId: number;
}