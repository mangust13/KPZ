export interface ClientLoginRequest {
    userName: string;
    password: string;
}