import { Component } from '@angular/core';

@Component({
  selector: 'app-client-auth-options',
  templateUrl: './client-auth-options.component.html',
  styleUrls: ['./client-auth-options.component.css']
})
export class ClientAuthOptionsComponent {

}
